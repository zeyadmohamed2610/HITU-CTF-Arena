import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuthStore } from '@/stores/authStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Flag, Trophy, Target, Zap } from 'lucide-react';

export default function DashboardPage() {
  const { profile, user } = useAuthStore();

  const { data: stats } = useQuery({
    queryKey: ['dashboard-stats', user?.id],
    queryFn: async () => {
      const [solvesRes, challengesRes, recentSolvesRes] = await Promise.all([
        supabase.from('solves').select('id', { count: 'exact' }).eq('user_id', user!.id),
        supabase.from('challenges').select('id', { count: 'exact' }).eq('is_active', true),
        supabase.from('solves').select('*, challenges(title)').eq('user_id', user!.id).order('created_at', { ascending: false }).limit(5),
      ]);
      return {
        solved: solvesRes.count ?? 0,
        total: challengesRes.count ?? 0,
        recentSolves: recentSolvesRes.data ?? [],
      };
    },
    enabled: !!user,
  });

  const statCards = [
    { title: 'Total Points', value: profile?.total_points ?? 0, icon: Trophy, color: 'text-primary' },
    { title: 'Challenges Solved', value: stats?.solved ?? 0, icon: Target, color: 'text-info' },
    { title: 'Active Challenges', value: stats?.total ?? 0, icon: Flag, color: 'text-warning' },
    { title: 'Completion', value: stats ? `${Math.round((stats.solved / Math.max(stats.total, 1)) * 100)}%` : '0%', icon: Zap, color: 'text-primary' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-sans font-bold">
          Welcome, <span className="text-gradient">{profile?.username || 'Player'}</span>
        </h1>
        <p className="text-muted-foreground mt-1">Your mission control center</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <Card key={stat.title} className="gradient-card border-border card-hover">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
              <stat.icon className={`h-5 w-5 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="gradient-card border-border">
        <CardHeader>
          <CardTitle className="text-lg font-sans">Recent Solves</CardTitle>
        </CardHeader>
        <CardContent>
          {stats?.recentSolves.length === 0 ? (
            <p className="text-muted-foreground text-sm">No solves yet. Start hacking!</p>
          ) : (
            <div className="space-y-2">
              {stats?.recentSolves.map((solve: any) => (
                <div key={solve.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <span className="text-sm font-medium">{solve.challenges?.title}</span>
                  <span className="text-sm text-primary font-mono">+{solve.points_awarded}pts</span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
