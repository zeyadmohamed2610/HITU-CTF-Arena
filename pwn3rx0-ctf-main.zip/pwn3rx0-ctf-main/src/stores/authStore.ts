import { create } from 'zustand';
import { supabase } from '@/integrations/supabase/client';
import type { User } from '@supabase/supabase-js';

export type AppRole = 'player' | 'ctf_author' | 'admin';

interface Profile {
  id: string;
  user_id: string;
  username: string | null;
  avatar_url: string | null;
  website: string | null;
  total_points: number;
  is_banned: boolean;
}

interface AuthState {
  user: User | null;
  profile: Profile | null;
  roles: AppRole[];
  loading: boolean;
  initialized: boolean;
  setUser: (user: User | null) => void;
  setProfile: (profile: Profile | null) => void;
  setRoles: (roles: AppRole[]) => void;
  setLoading: (loading: boolean) => void;
  setInitialized: (initialized: boolean) => void;
  isAdmin: () => boolean;
  isAuthor: () => boolean;
  isPlayer: () => boolean;
  hasRole: (role: AppRole) => boolean;
  initialize: () => Promise<void>;
  signOut: () => Promise<void>;
}

async function fetchUserData(userId: string) {
  const [profileRes, rolesRes] = await Promise.all([
    supabase.from('profiles').select('*').eq('user_id', userId).single(),
    supabase.from('user_roles').select('role').eq('user_id', userId),
  ]);
  return {
    profile: profileRes.data as Profile | null,
    roles: (rolesRes.data?.map((r) => r.role) as AppRole[]) ?? [],
  };
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  profile: null,
  roles: [],
  loading: true,
  initialized: false,

  setUser: (user) => set({ user }),
  setProfile: (profile) => set({ profile }),
  setRoles: (roles) => set({ roles }),
  setLoading: (loading) => set({ loading }),
  setInitialized: (initialized) => set({ initialized }),

  isAdmin: () => get().roles.includes('admin'),
  isAuthor: () => get().roles.includes('ctf_author'),
  isPlayer: () => get().roles.includes('player'),
  hasRole: (role) => get().roles.includes(role),

  initialize: async () => {
    // Prevent double init
    if (get().initialized) return;

    // Get initial session first
    const { data: { session } } = await supabase.auth.getSession();

    if (session?.user) {
      const { profile, roles } = await fetchUserData(session.user.id);
      set({ user: session.user, profile, roles, loading: false, initialized: true });
    } else {
      set({ user: null, profile: null, roles: [], loading: false, initialized: true });
    }

    // Listen for future changes
    supabase.auth.onAuthStateChange(async (event, session) => {
      const user = session?.user ?? null;

      if (user) {
        // Use setTimeout to avoid Supabase deadlock with getSession
        setTimeout(async () => {
          const { profile, roles } = await fetchUserData(user.id);
          set({ user, profile, roles, loading: false });
        }, 0);
      } else {
        set({ user: null, profile: null, roles: [], loading: false });
      }
    });
  },

  signOut: async () => {
    await supabase.auth.signOut();
    set({ user: null, profile: null, roles: [] });
  },
}));
